package com.louis.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.louis.dto.NewDTO;

public interface INewService {
	NewDTO save(NewDTO newDTO);
//	NewDTO update(NewDTO newDTO);
	void delete(long[] ids);
	List<NewDTO>findAll(Pageable pageable);
	List<NewDTO>findAll();
	int totalItem();
}
