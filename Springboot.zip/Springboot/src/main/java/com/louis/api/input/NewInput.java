package com.louis.api.input;

public class NewInput {

}
