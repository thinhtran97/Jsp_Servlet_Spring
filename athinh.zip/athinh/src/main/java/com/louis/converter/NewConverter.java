package com.louis.converter;

import org.springframework.stereotype.Component;

import com.louis.dto.NewDTO;
import com.louis.entity.NewEntity;


@Component
public class NewConverter {
	
	public NewEntity toEntity(NewDTO newDTO) {
		NewEntity entity = new NewEntity();
		entity.setTitle(newDTO.getTitle());
		entity.setContent(newDTO.getContent());
		entity.setShortDescription(newDTO.getShortDescription());
		entity.setThumbnail(newDTO.getThumbnail());
		return entity;
	}
	
	public NewDTO toDTO(NewEntity entity) {
		NewDTO dto = new NewDTO();
		if(entity.getId()!=null) {
			dto.setId(entity.getId());
		}
		dto.setTitle(entity.getTitle());
		dto.setContent(entity.getContent());
		dto.setShortDescription(entity.getShortDescription());
		dto.setThumbnail(entity.getThumbnail());
		dto.setCreatedDate(entity.getCreatedDate());
		dto.setCreatedBy(entity.getCreatedBy());
		dto.setModifiedDate(entity.getModifiedDate());
		dto.setModifiedBy(entity.getModifiedBy());
		return dto;
	}
	

	public NewEntity toEntity(NewDTO newDTO, NewEntity entity) {
//		NewEntity entity = new NewEntity();
		entity.setTitle(newDTO.getTitle());
		entity.setContent(newDTO.getContent());
		entity.setShortDescription(newDTO.getShortDescription());
		entity.setThumbnail(newDTO.getThumbnail());
		return entity;
	}

}
