package com.louis.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.louis.entity.NewEntity;


public interface NewRepository extends JpaRepository<NewEntity, Long> {
	

}
