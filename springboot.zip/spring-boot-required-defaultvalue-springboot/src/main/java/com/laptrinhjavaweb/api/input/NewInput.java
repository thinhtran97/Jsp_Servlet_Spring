package com.laptrinhjavaweb.api.input;

public class NewInput {

}
